# Python Automation UI

A user-friendly web interface that allows non-technical users to run Python automation scripts without dealing with command-line interfaces.

## Features

- Clean, intuitive web interface
- Dynamic parameter forms based on script configuration
- Support for different input types (text, select, textarea, checkbox)
- Real-time script execution with output display
- Easy to add new automation scripts
- TypeScript frontend for type safety
- Python Flask backend for reliable script execution

## Project Structure

```
python-automation-ui/
├── app.py                      # Flask backend server
├── automations_config.json     # Configuration for available automations
├── requirements.txt            # Python dependencies
├── package.json               # Node.js dependencies (for TypeScript)
├── tsconfig.json              # TypeScript configuration
├── scripts/                   # Python automation scripts
│   ├── file_organizer.py
│   ├── email_sender.py
│   └── data_backup.py
├── src/                       # TypeScript source files
│   └── app.ts
├── static/                    # Static assets
│   ├── css/
│   │   └── style.css
│   └── js/                    # Compiled TypeScript
│       └── app.js
└── templates/                 # HTML templates
    └── index.html
```

## Setup Instructions

### Prerequisites

- Python 3.8 or higher
- Node.js 16 or higher (for TypeScript compilation)
- pip (Python package manager)
- npm (Node.js package manager)

### Installation

1. **Install Python dependencies:**

```bash
pip install -r requirements.txt
```

2. **Install Node.js dependencies:**

```bash
npm install
```

3. **Compile TypeScript:**

```bash
npm run build
```

## Running the Application

1. **Start the Flask server:**

```bash
python app.py
```

2. **Open your browser:**

Navigate to `http://localhost:5000`

The application will be running and ready to use!

## How to Use

1. **Select an Automation:** Choose from the dropdown menu of available automations
2. **Fill Parameters:** Enter the required parameters in the dynamically generated form
3. **Run:** Click the "Run Automation" button
4. **View Output:** See the results in the output section below

## Adding New Automations

To add a new automation script, follow these steps:

### 1. Create Your Python Script

Create a new Python script in the `scripts/` directory:

```python
#!/usr/bin/env python3
import argparse

def main():
    parser = argparse.ArgumentParser(description='Your script description')
    parser.add_argument('--param1', required=True, help='Parameter 1')
    parser.add_argument('--param2', required=False, help='Parameter 2')

    args = parser.parse_args()

    # Your automation logic here
    print("Automation completed successfully!")

    return 0

if __name__ == '__main__':
    exit(main())
```

### 2. Update Configuration

Add your automation to `automations_config.json`:

```json
{
  "id": "your_automation_id",
  "name": "Your Automation Name",
  "description": "Brief description of what your automation does",
  "script": "scripts/your_script.py",
  "parameters": [
    {
      "name": "param1",
      "label": "Parameter 1 Label",
      "type": "text",
      "required": true,
      "placeholder": "Enter value..."
    }
  ]
}
```

### Parameter Types

The UI supports the following parameter types:

- **text**: Single-line text input
- **textarea**: Multi-line text input
- **select**: Dropdown selection (requires `options` array)
- **checkbox**: Boolean checkbox (use with `action='store_true'` in argparse)

### Parameter Configuration

Each parameter in the configuration can have:

- `name`: Parameter name (matches argparse argument)
- `label`: Display label in the UI
- `type`: Input type (text, textarea, select, checkbox)
- `required`: Whether the parameter is required (true/false)
- `placeholder`: Placeholder text for input fields (optional)
- `options`: Array of options for select dropdowns (required for select type)
- `default`: Default value (optional)

## Example Automations Included

### 1. File Organizer

Organizes files in a directory by extension, date, or size.

**Parameters:**
- Source Folder: Path to the folder to organize
- Organize By: Method (extension, date, size)

### 2. Bulk Email Sender

Simulates sending emails to multiple recipients (demo version).

**Parameters:**
- Recipients: Comma-separated email addresses
- Subject: Email subject line
- Message: Email body text

### 3. Data Backup

Creates backups of files with optional compression.

**Parameters:**
- Source: Path to backup
- Destination: Backup destination path
- Compress: Whether to compress the backup (checkbox)

## Development

### Watch Mode for TypeScript

For development, you can run TypeScript in watch mode:

```bash
npm run watch
```

This will automatically recompile TypeScript files when they change.

### Flask Debug Mode

The Flask server runs in debug mode by default, which means:
- Automatic reloading when Python files change
- Detailed error messages
- Debug toolbar (if installed)

## Security Considerations

**Important:** This application is designed for trusted environments. Consider these security measures for production:

1. **Authentication:** Add user authentication to restrict access
2. **Input Validation:** Validate all user inputs on the backend
3. **Path Restrictions:** Limit file system access to specific directories
4. **Sandboxing:** Run scripts in isolated environments
5. **Timeout Limits:** Configure appropriate timeout limits for long-running scripts
6. **HTTPS:** Use HTTPS in production environments
7. **Rate Limiting:** Implement rate limiting to prevent abuse

## Troubleshooting

### Port Already in Use

If port 5000 is already in use, modify the port in `app.py`:

```python
app.run(debug=True, host='0.0.0.0', port=5001)  # Change port number
```

### TypeScript Compilation Errors

Make sure you have the correct TypeScript version:

```bash
npm install typescript@latest
npm run build
```

### Python Script Not Found

Ensure your script paths in `automations_config.json` are relative to the project root.

### Permission Errors

On Unix systems, make sure your Python scripts are executable:

```bash
chmod +x scripts/*.py
```

## Contributing

To contribute to this project:

1. Add your automation script following the guidelines above
2. Update the configuration file
3. Test thoroughly with various inputs
4. Update documentation if needed

## License

MIT License - Feel free to use and modify for your needs.

## Support

For issues or questions, please check the troubleshooting section or create an issue in the project repository.
