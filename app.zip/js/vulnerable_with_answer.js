const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const { exec, spawn } = require('child_process'); // Import 'spawn' for safe execution
const app = express();
app.use(express.urlencoded({ extended: true }));

// Import security libraries
const bcrypt = require('bcrypt'); // `npm install bcrypt`
const DOMPurify = require('dompurify'); // `npm install dompurify`
const { JSDOM } = require('jsdom'); // `npm install jsdom`
const window = new JSDOM('').window;
const purify = DOMPurify(window);
app.set('view engine', 'ejs'); // `npm install ejs`

// Vulnerability 1: Hardcoded Secrets
// const API_KEY = 'secret-api-key-987654321';
// FIX: Load secrets from environment variables.
const API_KEY = process.env.API_KEY;
app.set('secret', API_KEY); 

const db = new sqlite3.Database(':memory:');
// ... (DB setup) ...

// ... (Mock session) ...

// Register a new user
app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    // Vulnerability 2: Insecure Password Storage
    // FIX: Hash the password using a strong, one-way, salted algorithm like bcrypt.
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // FIX: Use parameterized queries to prevent SQL Injection.
    const query = 'INSERT INTO users (username, password, is_admin) VALUES (?, ?, 0)';
    
    db.run(query, [username, passwordHash], function(err) {
        if (err) {
            return res.status(500).send('Error creating user.');
        }
        res.send(`User ${username} created with ID: ${this.lastID}`);
    });
});

// Login endpoint
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Vulnerability 3: SQL Injection
    // FIX: Use parameterized queries.
    const query = 'SELECT * FROM users WHERE username = ?';

    db.get(query, [username], async (err, user) => {
        if (err || !user) {
            // Use a generic error message to prevent username enumeration
            return res.status(401).send('Invalid username or password.');
        }

        // FIX: Compare the user-supplied password with the stored hash.
        const match = await bcrypt.compare(password, user.password);
        if (match) {
            // Set session, etc.
            res.send(`Welcome, ${user.username}! (User ID: ${user.id})`);
        } else {
            res.status(401).send('Invalid username or password.');
        }
    });
});

// Search endpoint
app.get('/search', (req, res) => {
    const searchTerm = req.query.q || '';

    // Vulnerability 4: Reflected Cross-Site Scripting (XSS)
    // FIX: Use a templating engine (like EJS) that performs
    // output encoding by default. This turns '<' into '&lt;', etc.
    
    // The EJS file ('views/search.ejs') would look like this:
    // <h1>Search Results</h1>
    // <p>You searched for: <%= searchTerm %></p> 
    // The <%= %> syntax performs the encoding.
    res.render('search', { searchTerm: searchTerm });
});

// View a user's profile
app.get('/profile/:id', (req, res) => {
    const profileIdToView = req.params.id;
    const currentUserId = req.session.user.id;
    const isAdmin = req.session.user.is_admin === 1;

    // Vulnerability 5: Insecure Direct Object Reference (IDOR)
    // FIX: Enforce an authorization check *before* fetching the data.
    // A user should only see their own profile, unless they are an admin.
    if (currentUserId.toString() !== profileIdToView && !isAdmin) {
        // Return a generic 404 to avoid leaking info that the profile exists.
        return res.status(404).send('Profile not found');
    }

    // Use parameterized query
    const query = 'SELECT u.username, p.bio FROM users u JOIN profiles p ON u.id = p.user_id WHERE u.id = ?';

    db.get(query, [profileIdToView], (err, profile) => {
        if (err || !profile) {
            return res.status(404).send('Profile not found');
        }

        // Vulnerability 6: Stored Cross-Site Scripting (XSS)
        // The 'bio' from the DB is malicious.
        // FIX 1 (Input): Sanitize the 'bio' *before* saving it to the DB
        // (e.g., in a PUT /profile route) using DOMPurify.
        // const cleanBio = purify.sanitize(req.body.bio);
        
        // FIX 2 (Output): Use a templating engine to encode the output.
        // The EJS file ('views/profile.ejs') would be:
        // <h1><%= username %>'s Profile</h1>
        // <p>Bio: <%= bio %></p>
        res.render('profile', { username: profile.username, bio: profile.bio });
    });
});

// Network diagnostic tool
app.post('/api/diagnostics', (req, res) => {
    // FIX: Use a strict equality check for authorization
    if (req.session.user.is_admin !== 1) {
        return res.status(403).send('Forbidden.');
    }
    
    const { host } = req.body;

    // Vulnerability 7: Command Injection
    // FIX: Never use exec() with user input. Use spawn() which
    // treats arguments as separate tokens, not as a single command string.
    // The shell (';', '&&', etc.) will not interpret the 'host' argument.
    const ping = spawn('ping', ['-c', '3', host]);
    let output = '';

    ping.stdout.on('data', (data) => {
        output += data.toString();
    });

    ping.stderr.on('data', (data) => {
        output += `StdErr: ${data.toString()}`;
    });

    ping.on('close', (code) => {
        // FIX: Also ensure output is encoded before sending to browser.
        res.setHeader('Content-Type', 'text/plain');
        res.send(output);
    });
});

// app.listen(3000, ...);