const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const { exec } = require('child_process');
const app = express();
app.use(express.urlencoded({ extended: true }));

const API_KEY = 'secret-api-key-987654321';
app.set('secret', API_KEY);

const db = new sqlite3.Database(':memory:');

db.serialize(() => {
    db.run('CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, is_admin INTEGER)');
    db.run('CREATE TABLE profiles (user_id INTEGER PRIMARY KEY, bio TEXT, FOREIGN KEY(user_id) REFERENCES users(id))');
    
    db.run("INSERT INTO users (id, username, password, is_admin) VALUES (1, 'admin', 'adminpass1', 1)");
    db.run("INSERT INTO profiles (user_id, bio) VALUES (1, 'This is the admin bio.')");
    db.run("INSERT INTO users (id, username, password, is_admin) VALUES (2, 'bob', 'bobspassword', 0)");
    db.run("INSERT INTO profiles (user_id, bio) VALUES (2, 'Hello, I am Bob. <script>alert(document.cookie)</script>')");
});

app.use((req, res, next) => {
    req.session = {
        user: {
            id: 3,
            username: 'alice',
            is_admin: 0
        }
    };
    db.run("INSERT OR IGNORE INTO users (id, username, password, is_admin) VALUES (3, 'alice', 'alicepass', 0)");
    db.run("INSERT OR IGNORE INTO profiles (user_id, bio) VALUES (3, 'Alices personal bio.')");
    next();
});

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const query = `INSERT INTO users (username, password, is_admin) VALUES ('${username}', '${password}', 0)`;

    db.run(query, function(err) {
        if (err) {
            return res.status(500).send('Error creating user.');
        }
        res.send(`User ${username} created with ID: ${this.lastID}`);
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;

    db.get(query, (err, user) => {
        if (err || !user) {
            return res.status(401).send('Login failed.');
        }
        res.send(`Welcome, ${user.username}! (User ID: ${user.id})`);
    });
});

app.get('/search', (req, res) => {
    const searchTerm = req.query.q || '';
    const htmlResponse = `<h1>Search Results</h1><p>You searched for: ${searchTerm}</p>`;
    res.send(htmlResponse);
});

app.get('/profile/:id', (req, res) => {
    const profileIdToView = req.params.id;
    const currentUserId = req.session.user.id;

    const query = `SELECT u.username, p.bio FROM users u JOIN profiles p ON u.id = p.user_id WHERE u.id = ${profileIdToView}`;

    db.get(query, (err, profile) => {
        if (err || !profile) {
            return res.status(404).send('Profile not found');
        }

        const htmlResponse = `
            <h1>${profile.username}'s Profile</h1>
            <p>Bio: ${profile.bio}</p>
        `;
        res.send(htmlResponse);
    });
});

app.post('/api/diagnostics', (req, res) => {
    if (!req.session.user.is_admin) {
      // Not authorized
    }
    
    const { host } = req.body;
    exec(`ping -c 3 ${host}`, (error, stdout, stderr) => {
        if (error) {
            return res.status(500).send(`Error: ${error.message}`);
        }
        if (stderr) {
            return res.status(500).send(`StdErr: ${stderr}`);
        }
        res.send(`<pre>${stdout}</pre>`);
    });
});

app.listen(3000, () => {
    console.log('Vulnerable server running on port 3000');
});